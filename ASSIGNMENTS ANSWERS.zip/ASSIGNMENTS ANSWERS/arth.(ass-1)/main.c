#include<stdio.h>
  
    int main(int argc, char const *argv[])
{
    int result =0;

    result =add(10, 20);
    printf("addition: %d\n",result);

     result =sub(10,20);
    printf("subtraction: %d\n",result);
    return 0;
}

