int add(int, int,int);
int sub(int,int);