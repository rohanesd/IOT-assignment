#include<stdio.h>

 int main(int argc,char const *argv[])
 {
     int *ptr=NULL;

     printf("addr =%d\n",*ptr);
     return 0;
 }
